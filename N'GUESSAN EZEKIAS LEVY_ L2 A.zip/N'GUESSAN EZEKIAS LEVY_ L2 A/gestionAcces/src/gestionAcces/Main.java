package gestionAcces;

import java.util.Scanner;


public class Main {

	 private static final int MAX_ATTEMPTS = 2;
	
	public static void main(String[] args) {
		CentreDeControleDacces system = new CentreDeControleDacces();
		
		Circuit entrerDansCircuit = new Circuit();
		system.registreDesProprietaires("entrer", entrerDansCircuit);
		
		 Scanner scanner = new Scanner(System.in);
	        String IdentifiantDeCarte = "";
	        String MotDePasse = "";
	        int tentative = 0;
	        
	        
	        while (tentative < MAX_ATTEMPTS) {
	            System.out.print("Veuillez saisir votre numéro de carte : ");
	            IdentifiantDeCarte = scanner.nextLine();

	            System.out.print("Veuillez saisir votre code d'accès : ");
	            MotDePasse = scanner.nextLine();

	            if (system.AccesAccordee("Entree", IdentifiantDeCarte, MotDePasse)) {
	                System.out.println("Accès accordé. Bienvenue dans le système.");
	                break;
	            } else {
	                tentative++;
	                System.out.println("Accès refusé. Veuillez réessayer.");
	                if (tentative < MAX_ATTEMPTS) {
	                    System.out.println("Bip bip bip... (Alarme déclenchée)");
	                }
	            }
	        }
	        
	        if (tentative == MAX_ATTEMPTS) {
	            System.out.println("Trop de tentatives. L'alarme a été déclenchée.");
	        }

	        scanner.close();
	    }
	
}


