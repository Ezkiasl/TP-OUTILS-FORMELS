package gestionAcces;

public class AccesAuControle {
	 private enum Etat {
	        CARD_VERIFICATION,
	        CODE_VERIFICATION,
	        ACCESS_GRANTED,
	        ACCESS_DENIED,
	        ALARM_TRIGGERED
	    }
	
	 
	 private Etat DiffEtat;
	 
	 public AccesAuControle(){
		 DiffEtat = Etat.CARD_VERIFICATION;
	    }
	 public void validationCarte(boolean carteEstValide) {
	        switch(DiffEtat){
	        
	        case CARD_VERIFICATION: 
	        	
	        	if (carteEstValide) {
                DiffEtat = Etat.CODE_VERIFICATION;
            } else {
                DiffEtat = Etat.ACCESS_DENIED;
            }
            break;
        case CODE_VERIFICATION:
        case ACCESS_GRANTED:
        case ACCESS_DENIED:
        case ALARM_TRIGGERED:
          
            break;
	        
	       }
	    }
	 
	 public void validationCode(boolean CodeEstValide) {
	        switch (DiffEtat) {
	            case CODE_VERIFICATION:
	                if (CodeEstValide) {
	                    DiffEtat = Etat.ACCESS_GRANTED;
	                } else {
	                    DiffEtat = Etat.ACCESS_DENIED;
	                }
	                break;
	            case CARD_VERIFICATION:
	            case ACCESS_GRANTED:
	            case ACCESS_DENIED:
	            case ALARM_TRIGGERED:
	              
	                break;
	        }
	    }

	 public void alarmeEstDeclenchee(boolean alarmeDeclenchee) {
	        if (alarmeDeclenchee) {
	            DiffEtat = Etat.ALARM_TRIGGERED;
	        }
	    }

	    public Etat getDiffEtat() {
	        return DiffEtat;
	    }
   
}
