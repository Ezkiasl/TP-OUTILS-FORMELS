package gestionAcces;

public class GestionValidation {
	private boolean cartevalide;
	private boolean codevalide;
	private boolean alerteDeclenchee;
	
	
	public boolean AccesAccordee(){
		 
		return(cartevalide && codevalide);
	}

	public boolean Accesrefusee(){
		 
		return(!cartevalide || !codevalide);
	}

	public boolean alarmeEstDeclenclee(){
		 
		return(alerteDeclenchee);
	}
	public void validationCarte(boolean carteEstValide){
		 
		this.cartevalide=carteEstValide;
	}
	public void validationCode(boolean codeEstValide){
		 
		this.codevalide=codeEstValide;
  }
	public void intruiDetectee(boolean Alarme){
		 
		this.alerteDeclenchee=Alarme;
  }
	
}
