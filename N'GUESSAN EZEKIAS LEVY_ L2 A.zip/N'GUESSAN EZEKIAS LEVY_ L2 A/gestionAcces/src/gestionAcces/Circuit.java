package gestionAcces;

public class Circuit {
	private boolean carteValide;
	private boolean codeValide;
	private boolean alerteIntrui;
	
	public boolean AccesAutorise(){
		return (carteValide && codeValide);
	}
	public boolean Accesrefusee(){
		 
		return(!carteValide || !codeValide);
	}

	 public boolean alarmeDeclenchee() {
	        return alerteIntrui;
	    }

	    public void verificationCarte(boolean CarteEstValid) {
	        this.carteValide = CarteEstValid;
	    }

	    public void verificationCode(boolean CodeParfait) {
	        this.codeValide = CodeParfait;
	    }

	    public void detectIntrusion(boolean InfractionCommise) {
	        this.alerteIntrui= InfractionCommise;
	    }

	    public void resetSystem() {
	        this.carteValide = false;
	        this.codeValide = false;
	        this.alerteIntrui = false;
	    }
}
