package gestionAcces;

import java.util.HashMap;
import java.util.Map;


public class CentreDeControleDacces {
	private Map<String, Circuit> circuits;
	
	 public CentreDeControleDacces() {
	        circuits = new HashMap<>();
	    }

	 public void registreDesProprietaires(String Identifiant, Circuit circuit) {
	        circuits.put(Identifiant, circuit);
	    }
	 public boolean AccesAccordee(String  Identifiant, String  IdentifiantDeCarte, String MotDePasse) {
	       Circuit circuit = circuits.get( Identifiant);
	        if (circuit == null) {
	            return false;
	        }
	        
	  circuit.verificationCarte(true);
	  
	  circuit.verificationCode(true);
	  
	  
	  return circuit.AccesAutorise();
	 }
	 public boolean Accesrefusee(String  Identifiant, String  IdentifiantDeCarte, String MotDePasse) {
	       Circuit circuit = circuits.get( Identifiant);
	        if (circuit == null) {
	            return false;
	        }
	        
	  circuit.verificationCarte(false);
	  
	  circuit.verificationCode(false);
	  
	  
	  return circuit.Accesrefusee();
	 }
	 public boolean alarmeDeclenchee(String  Identifiant) {
	       Circuit circuit = circuits.get( Identifiant);
	        if (circuit == null) {
	            return false;
	        }
	        
	        
	      return circuit.alarmeDeclenchee();
	 }
	 private boolean CarteEstValid(String  Identifiant) {
	      return (true);
	 }
	 private boolean CodeParfait(String  MotDePasse) {
	      return (true);
	 }
}
